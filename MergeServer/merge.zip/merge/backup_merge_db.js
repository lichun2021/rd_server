const fs = require('fs');
const path = require('path');
const { spawnSync, spawn } = require('child_process');

const SCRIPT_DIR = __dirname;
const CONFIG_FILE = path.join(SCRIPT_DIR, 'cfg', 'mergeDb.cfg');
const MYSQL_BIN = process.env.MYSQL_BIN || 'mysql';
const MYSQLDUMP_BIN = process.env.MYSQLDUMP_BIN || 'mysqldump';

if (!fs.existsSync(CONFIG_FILE)) {
  console.error(`[ERROR] 找不到配置文件: ${CONFIG_FILE}`);
  process.exit(1);
}

function parseCfg(file) {
  const cfg = {};
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith('#') || !line.includes('=')) continue;
    const [k, v] = line.split('=', 2).map(s => s.trim());
    cfg[k] = v;
  }
  return cfg;
}

const cfg = parseCfg(CONFIG_FILE);
if (!cfg.dbNames) {
  console.error('[ERROR] 配置项 dbNames 为空');
  process.exit(1);
}

const pickFirst = (val, def = '') =>
  (val || '').split(',').map(s => s.trim()).filter(Boolean)[0] || def;

const dbNames = cfg.dbNames.split(',').map(s => s.trim()).filter(Boolean);
const host = pickFirst(cfg.dbHosts, '127.0.0.1');
const port = pickFirst(cfg.dbPorts, '3306');
const user = pickFirst(cfg.dbUsernames, 'root');
const pass = pickFirst(cfg.dbPasswords, '');

function mysqlExec(sql) {
  const args = ['-h', host, '-P', port, '-u', user, `-p${pass}`, '-N', '-B', '-e', sql];
  const res = spawnSync(MYSQL_BIN, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'inherit'] });
  if (res.status !== 0) {
    console.error(`[ERROR] mysql 执行失败: ${sql}`);
    process.exit(1);
  }
  return res.stdout.trim();
}

function backupOne(srcDb, dstDb) {
  console.log(`[CHECK] ${dstDb}`);
  const exists = mysqlExec(`SHOW DATABASES LIKE '${dstDb}';`);
  if (exists) {
    console.log(`[SKIP] ${dstDb} 已存在，跳过`);
    return Promise.resolve();
  }

  console.log(`[CREATE] ${dstDb}`);
  mysqlExec(`CREATE DATABASE IF NOT EXISTS \\\`${dstDb}\\\` DEFAULT CHARACTER SET utf8mb4;`);

  console.log(`[DUMP] ${srcDb} -> ${dstDb}`);
  return new Promise((resolve, reject) => {
    const dumpArgs = ['-h', host, '-P', port, '-u', user, `-p${pass}`, '--single-transaction', '--routines', '--events', '--triggers', srcDb];
    const restoreArgs = ['-h', host, '-P', port, '-u', user, `-p${pass}`, dstDb];

    const dump = spawn(MYSQLDUMP_BIN, dumpArgs, { stdio: ['ignore', 'pipe', 'inherit'] });
    const restore = spawn(MYSQL_BIN, restoreArgs, { stdio: ['pipe', 'inherit', 'inherit'] });

    dump.stdout.pipe(restore.stdin);

    let dumpDone = false;
    let restoreDone = false;
    let dumpCode = 0;
    let restoreCode = 0;

    const finish = () => {
      if (!dumpDone || !restoreDone) return;
      if (dumpCode === 0 && restoreCode === 0) {
        console.log(`[OK] ${srcDb} -> ${dstDb}`);
        resolve();
      } else {
        reject(new Error(`mysqldump exit ${dumpCode}, mysql exit ${restoreCode}`));
      }
    };

    dump.on('error', reject);
    restore.on('error', reject);

    dump.on('exit', code => {
      dumpDone = true;
      dumpCode = code;
      try { restore.stdin.end(); } catch (_) {}
      finish();
    });

    restore.on('exit', code => {
      restoreDone = true;
      restoreCode = code;
      finish();
    });
  });
}

(async () => {
  console.log('使用配置:');
  console.log(`  dbHosts=${host} dbPorts=${port} dbUsernames=${user}`);
  console.log(`  dbNames=${dbNames.join(',')}`);
  console.log('');

  for (const db of dbNames) {
    const dst = `${db}_backup`;
    await backupOne(db, dst);
  }

  console.log('完成');
})().catch(err => {
  console.error('[ERROR]', err.message || err);
  process.exit(1);
});

