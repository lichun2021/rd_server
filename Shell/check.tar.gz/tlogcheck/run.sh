java -jar tloganalyzer.jar -Dfile.encoding=UTF-8
